package com.hubzones;

import org.bukkit.block.Block;
import org.bukkit.entity.EntityType;
import org.bukkit.util.BoundingBox;

import java.util.ArrayList;
import java.util.List;

public class Zone {
    public final String name;
    public final ZoneType type;
    public final String world;
    public final int minX, minY, minZ, maxX, maxY, maxZ;

    // combat zone settings
    public EntityType mobType = EntityType.ZOMBIE;
    public int maxMobs = 6;
    public int respawnSeconds = 5;
    public final List<Long> respawnQueue = new ArrayList<>();

    public Zone(String name, ZoneType type, String world,
                int x1, int y1, int z1, int x2, int y2, int z2) {
        this.name = name;
        this.type = type;
        this.world = world;
        this.minX = Math.min(x1, x2);
        this.minY = Math.min(y1, y2);
        this.minZ = Math.min(z1, z2);
        this.maxX = Math.max(x1, x2);
        this.maxY = Math.max(y1, y2);
        this.maxZ = Math.max(z1, z2);
    }

    public boolean contains(Block b) {
        return b.getWorld().getName().equals(world)
                && b.getX() >= minX && b.getX() <= maxX
                && b.getY() >= minY && b.getY() <= maxY
                && b.getZ() >= minZ && b.getZ() <= maxZ;
    }

    public BoundingBox box() {
        return new BoundingBox(minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1);
    }
}
