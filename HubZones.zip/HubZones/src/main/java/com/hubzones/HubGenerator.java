package com.hubzones;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Sign;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.Rotatable;
import org.bukkit.block.data.type.Farmland;
import org.bukkit.block.data.type.Fence;
import org.bukkit.block.data.type.Leaves;
import org.bukkit.block.sign.Side;
import org.bukkit.block.sign.SignSide;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * Builds a floating hub island: fountain plaza in the middle, four paths,
 * and four zones (mine / farm / forest / arena). Blocks are placed over
 * several ticks so the server doesn't freeze.
 */
public class HubGenerator {

    private static final int R = 56;            // island radius
    private static final int AREA_START = 27;   // distance from centre where each area begins
    private static final int HALF = 11;         // area half-width (lateral)
    private static final int LEN = 22;          // area length (outwards)
    private static final int OPS_PER_TICK = 6000;

    // outward direction per area: N, E, S, W
    private static final int[][] OUT = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};

    private static class Op {
        int x, y, z;
        BlockData d;
    }

    private final HubZones plugin;
    private final Player player;
    private final World w;
    private final int cx, cz, y0;
    private final Random rnd = new Random();

    private final LinkedHashMap<Long, Op> ops = new LinkedHashMap<>();
    private final Map<Material, BlockData> cache = new EnumMap<>(Material.class);
    private final Map<Material, BlockData> cropCache = new EnumMap<>(Material.class);
    private final Map<Material, BlockData> leafCache = new EnumMap<>(Material.class);
    private final Set<Long> reserved = new HashSet<>();
    private final List<Runnable> post = new ArrayList<>();
    private final List<Zone> newZones = new ArrayList<>();

    public HubGenerator(HubZones plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        this.w = player.getWorld();
        this.cx = player.getLocation().getBlockX();
        this.cz = player.getLocation().getBlockZ();
        this.y0 = player.getLocation().getBlockY() - 1;
    }

    // ------------------------------------------------------------ entry point

    public void start() {
        if (y0 - 21 < w.getMinHeight() || y0 + 16 > w.getMaxHeight()) {
            player.sendMessage(ChatColor_RED + "Not enough vertical room here. Stand around y=100 in the world and try again.");
            return;
        }

        build();

        // keep the player safe while blocks appear around/under them
        Location safe = new Location(w, cx + 0.5, y0 + 9, cz + 8.5, 180f, 0f);
        player.teleport(safe);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 400, 0));
        player.sendMessage("[HubZones] Building hub (" + ops.size() + " blocks)... this takes a few seconds.");

        final Iterator<Op> it = ops.values().iterator();
        new BukkitRunnable() {
            @Override
            public void run() {
                int n = 0;
                while (it.hasNext() && n < OPS_PER_TICK) {
                    Op o = it.next();
                    w.getBlockAt(o.x, o.y, o.z).setBlockData(o.d, false);
                    n++;
                }
                if (!it.hasNext()) {
                    cancel();
                    finish();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private static final String ChatColor_RED = "\u00a7c";

    private void finish() {
        for (Runnable r : post) r.run();

        Location spawn = new Location(w, cx + 0.5, y0 + 1, cz + 8.5, 180f, 0f);
        plugin.registerGeneratedHub(spawn, newZones);

        if (player.isOnline()) {
            player.teleport(spawn);
            player.setFallDistance(0);
            player.sendMessage("\u00a76[HubZones] \u00a7fHub ready! Zones created: mine, farm, forest, arena. Hub point is set (/hub).");
        }
    }

    // ------------------------------------------------------------ block helpers

    private static long key(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFFL) << 38) | ((long) (z & 0x3FFFFFFL) << 12) | ((y + 2048) & 0xFFFL);
    }

    private BlockData data(Material m) {
        return cache.computeIfAbsent(m, mm -> mm.createBlockData());
    }

    private void set(int x, int y, int z, BlockData d) {
        long k = key(x, y, z);
        Op o = ops.get(k);
        if (o == null) {
            o = new Op();
            o.x = x;
            o.y = y;
            o.z = z;
            ops.put(k, o);
        }
        o.d = d;
    }

    private void set(int x, int y, int z, Material m) {
        set(x, y, z, data(m));
    }

    private Material typeAt(int x, int y, int z) {
        Op o = ops.get(key(x, y, z));
        return o == null ? null : o.d.getMaterial();
    }

    private static long col(int x, int z) {
        return ((long) x << 32) ^ (z & 0xFFFFFFFFL);
    }

    private static BlockFace face(int dx, int dz) {
        if (dz < 0) return BlockFace.NORTH;
        if (dz > 0) return BlockFace.SOUTH;
        if (dx > 0) return BlockFace.EAST;
        return BlockFace.WEST;
    }

    private void lamp(int x, int z) {
        set(x, y0 + 1, z, Material.DARK_OAK_FENCE);
        set(x, y0 + 2, z, Material.DARK_OAK_FENCE);
        set(x, y0 + 3, z, Material.DARK_OAK_FENCE);
        set(x, y0 + 4, z, Material.LANTERN);
    }

    // local area coordinates -> world
    private int wx(int dir, int lx, int lz) {
        return cx + OUT[dir][0] * (AREA_START + lz) + (-OUT[dir][1]) * lx;
    }

    private int wz(int dir, int lx, int lz) {
        return cz + OUT[dir][1] * (AREA_START + lz) + OUT[dir][0] * lx;
    }

    private void reserveArea(int dir) {
        for (int lz = -1; lz <= LEN + 1; lz++) {
            for (int lx = -HALF - 1; lx <= HALF + 1; lx++) {
                reserved.add(col(wx(dir, lx, lz), wz(dir, lx, lz)));
            }
        }
    }

    private Zone addZone(String name, ZoneType type, int dir, int lx1, int lz1, int lx2, int lz2, int yMin, int yMax) {
        Zone z = new Zone(name, type, w.getName(),
                wx(dir, lx1, lz1), yMin, wz(dir, lx1, lz1),
                wx(dir, lx2, lz2), yMax, wz(dir, lx2, lz2));
        newZones.add(z);
        return z;
    }

    // ------------------------------------------------------------ build

    private void build() {
        for (int dir = 0; dir < 4; dir++) reserveArea(dir);

        buildIsland();
        buildPlaza();
        buildPaths();
        buildMine(0);
        buildFarm(1);
        buildForest(2);
        buildArena(3);
        buildDecoration();
        finishFences();
    }

    private void buildIsland() {
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > R) continue;
                int x = cx + dx, z = cz + dz;

                set(x, y0, z, Material.GRASS_BLOCK);
                int depth = 3 + (int) Math.round(15 * (1 - d / R)) + rnd.nextInt(3) - 1;
                if (depth < 2) depth = 2;
                for (int i = 1; i <= depth; i++) {
                    Material m;
                    if (i <= 2) {
                        m = Material.DIRT;
                    } else {
                        int r = rnd.nextInt(12);
                        m = r == 0 ? Material.ANDESITE : (r == 1 ? Material.COBBLESTONE : Material.STONE);
                    }
                    set(x, y0 - i, z, m);
                }

                // fence ring along the edge
                if (d >= R - 2 && d <= R - 0.5) {
                    set(x, y0 + 1, z, Material.DARK_OAK_FENCE);
                }
            }
        }
        // lamp posts around the edge
        for (int deg = 0; deg < 360; deg += 12) {
            double rad = Math.toRadians(deg);
            lamp(cx + (int) Math.round((R - 1.2) * Math.cos(rad)),
                    cz + (int) Math.round((R - 1.2) * Math.sin(rad)));
        }
    }

    private void buildPlaza() {
        int pr = 15;
        for (int dx = -pr; dx <= pr; dx++) {
            for (int dz = -pr; dz <= pr; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > pr) continue;
                int x = cx + dx, z = cz + dz;

                Material m;
                if (d > 14) m = Material.POLISHED_BLACKSTONE_BRICKS;
                else m = (((int) (d / 2.5)) % 2 == 0) ? Material.STONE_BRICKS : Material.POLISHED_ANDESITE;
                set(x, y0, z, m);

                // remove edge fence/lamps if the plaza overlaps (it doesn't, but be safe)
                if (d <= 3.2 && d > 2.2) {
                    set(x, y0, z, Material.QUARTZ_BLOCK);
                    set(x, y0 + 1, z, Material.QUARTZ_SLAB);
                } else if (d <= 2.2) {
                    set(x, y0 - 1, z, Material.SMOOTH_QUARTZ);
                    set(x, y0, z, Material.WATER);
                }
            }
        }
        // centre pillar
        for (int y = 0; y <= 4; y++) set(cx, y0 + y, cz, Material.QUARTZ_PILLAR);
        set(cx, y0 + 5, cz, Material.SEA_LANTERN);

        // corner lamps
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                lamp(cx + 11 * sx, cz + 11 * sz);
            }
        }
    }

    private Material pathMat() {
        int r = rnd.nextInt(100);
        if (r < 70) return Material.STONE_BRICKS;
        if (r < 85) return Material.CRACKED_STONE_BRICKS;
        return Material.MOSSY_STONE_BRICKS;
    }

    private void buildPaths() {
        String[] titles = {"MINING", "FARMING", "FOREST", "ARENA"};
        String[] subs = {"Mine ores!", "Harvest crops!", "Chop trees!", "Fight mobs!"};

        for (int dir = 0; dir < 4; dir++) {
            final int ox = OUT[dir][0], oz = OUT[dir][1];
            final int px = -oz, pz = ox;

            for (int D = 13; D < AREA_START; D++) {
                for (int lat = -2; lat <= 2; lat++) {
                    set(cx + ox * D + px * lat, y0, cz + oz * D + pz * lat, pathMat());
                }
            }
            for (int D : new int[]{17, 23}) {
                for (int sgn = -1; sgn <= 1; sgn += 2) {
                    lamp(cx + ox * D + px * 3 * sgn, cz + oz * D + pz * 3 * sgn);
                }
            }

            // sign facing the plaza
            final int sx = cx + ox * 15 + px * 3, sz = cz + oz * 15 + pz * 3;
            BlockData sd = Material.OAK_SIGN.createBlockData();
            ((Rotatable) sd).setRotation(face(-ox, -oz));
            set(sx, y0 + 1, sz, sd);
            final String t = titles[dir], s = subs[dir];
            post.add(() -> {
                Block b = w.getBlockAt(sx, y0 + 1, sz);
                if (b.getState() instanceof Sign sign) {
                    SignSide side = sign.getSide(Side.FRONT);
                    side.setLine(0, "\u00a78\u2022 \u00a76\u00a7l" + t + " \u00a78\u2022");
                    side.setLine(1, "");
                    side.setLine(2, "\u00a77" + s);
                    side.setLine(3, "\u00a78\u2193");
                    sign.update();
                }
            });
        }
    }

    // ---------------------------------------------------------- MINE

    private Material mineBlock(int yo) {
        double r = rnd.nextDouble();
        double t = 0;
        t += 0.05;
        if (r < t) return Material.COAL_ORE;
        t += 0.035;
        if (r < t) return Material.IRON_ORE;
        t += 0.03;
        if (r < t) return Material.COPPER_ORE;
        if (yo <= 3) {
            t += 0.015;
            if (r < t) return Material.GOLD_ORE;
            t += 0.02;
            if (r < t) return Material.REDSTONE_ORE;
            t += 0.015;
            if (r < t) return Material.LAPIS_ORE;
        }
        if (yo <= 2) {
            t += 0.008;
            if (r < t) return Material.DIAMOND_ORE;
            t += 0.004;
            if (r < t) return Material.EMERALD_ORE;
        }
        int b = rnd.nextInt(10);
        if (b == 0) return Material.ANDESITE;
        if (b <= 2) return Material.COBBLESTONE;
        return Material.STONE;
    }

    private void buildMine(int dir) {
        for (int lz = 0; lz <= LEN; lz++) {
            for (int lx = -HALF; lx <= HALF; lx++) {
                int h = Math.min(8, 1 + lz / 3 + rnd.nextInt(2));
                int x = wx(dir, lx, lz), z = wz(dir, lx, lz);
                for (int yo = 0; yo <= h; yo++) {
                    set(x, y0 + yo, z, mineBlock(yo));
                }
            }
        }
        addZone("mine", ZoneType.MINING, dir, -HALF, 0, HALF, LEN, y0, y0 + 8);
    }

    // ---------------------------------------------------------- FARM

    private BlockData crop(Material m) {
        return cropCache.computeIfAbsent(m, mm -> {
            BlockData d = mm.createBlockData();
            if (d instanceof Ageable a) a.setAge(a.getMaximumAge());
            return d;
        });
    }

    private void buildFarm(int dir) {
        Farmland fl = (Farmland) Material.FARMLAND.createBlockData();
        fl.setMoisture(fl.getMaximumMoisture());
        Material[] crops = {Material.WHEAT, Material.CARROTS, Material.POTATOES, Material.BEETROOTS, Material.WHEAT};

        for (int lz = 2; lz <= LEN - 1; lz++) {
            boolean water = ((lz - 2) % 4 == 0);
            for (int lx = -9; lx <= 9; lx++) {
                int x = wx(dir, lx, lz), z = wz(dir, lx, lz);
                if (water) {
                    set(x, y0, z, Material.WATER);
                } else {
                    set(x, y0, z, fl);
                    set(x, y0 + 1, z, crop(crops[(lz - 2) / 4]));
                }
            }
        }

        // fence border (open on the path side)
        for (int lx = -HALF; lx <= HALF; lx++) {
            set(wx(dir, lx, LEN), y0 + 1, wz(dir, lx, LEN), Material.OAK_FENCE);
        }
        for (int lz = 0; lz <= LEN; lz++) {
            set(wx(dir, -HALF, lz), y0 + 1, wz(dir, -HALF, lz), Material.OAK_FENCE);
            set(wx(dir, HALF, lz), y0 + 1, wz(dir, HALF, lz), Material.OAK_FENCE);
        }

        // two scarecrows near the entrance
        for (int sgn = -1; sgn <= 1; sgn += 2) {
            int x = wx(dir, 6 * sgn, 0), z = wz(dir, 6 * sgn, 0);
            set(x, y0 + 1, z, Material.OAK_FENCE);
            set(x, y0 + 2, z, Material.HAY_BLOCK);
            set(x, y0 + 3, z, Material.CARVED_PUMPKIN);
        }

        addZone("farm", ZoneType.FARMING, dir, -HALF, 0, HALF, LEN, y0, y0 + 2);
    }

    // ---------------------------------------------------------- FOREST

    private BlockData leaf(Material m) {
        return leafCache.computeIfAbsent(m, mm -> {
            BlockData d = mm.createBlockData();
            if (d instanceof Leaves lv) lv.setPersistent(true);
            return d;
        });
    }

    private void putLeaf(int x, int y, int z, Material leafMat) {
        Material ex = typeAt(x, y, z);
        if (ex != null && ex.name().endsWith("_LOG")) return;
        set(x, y, z, leaf(leafMat));
    }

    private void tree(int x, int z, int kind, int h) {
        Material log = kind == 0 ? Material.OAK_LOG : (kind == 1 ? Material.BIRCH_LOG : Material.SPRUCE_LOG);
        Material lv = kind == 0 ? Material.OAK_LEAVES : (kind == 1 ? Material.BIRCH_LEAVES : Material.SPRUCE_LEAVES);

        for (int i = 1; i <= h; i++) set(x, y0 + i, z, log);

        if (kind != 2) {
            for (int dy = h - 2; dy <= h + 1; dy++) {
                int r = dy <= h - 1 ? 2 : 1;
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (dx == 0 && dz == 0 && dy <= h) continue;
                        boolean corner = Math.abs(dx) == r && Math.abs(dz) == r;
                        if (corner && (dy > h - 1 || rnd.nextBoolean())) continue;
                        putLeaf(x + dx, y0 + dy, z + dz, lv);
                    }
                }
            }
        } else {
            for (int dy = 3; dy <= h + 2; dy++) {
                int k = h + 2 - dy;
                int r = (k == 0) ? 0 : (k % 2 == 1 ? 1 : 2);
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (dx == 0 && dz == 0 && dy <= h) continue;
                        if (r == 2 && Math.abs(dx) == 2 && Math.abs(dz) == 2) continue;
                        putLeaf(x + dx, y0 + dy, z + dz, lv);
                    }
                }
            }
        }
    }

    private void buildForest(int dir) {
        int[] lxs = {-8, -4, 0, 4, 8};
        int[] lzs = {4, 9, 14, 19};
        for (int lz0 : lzs) {
            for (int lx0 : lxs) {
                if (rnd.nextInt(100) < 15) continue;
                int lx = Math.max(-9, Math.min(9, lx0 + rnd.nextInt(3) - 1));
                int lz = Math.max(3, Math.min(20, lz0 + rnd.nextInt(3) - 1));
                int kind = rnd.nextInt(3);
                int h = kind == 0 ? 5 + rnd.nextInt(2) : (kind == 1 ? 6 + rnd.nextInt(2) : 7 + rnd.nextInt(2));
                tree(wx(dir, lx, lz), wz(dir, lx, lz), kind, h);
            }
        }
        addZone("forest", ZoneType.TREE, dir, -HALF, 0, HALF, LEN, y0, y0 + 10);
    }

    // ---------------------------------------------------------- ARENA

    private Material wallMat() {
        int r = rnd.nextInt(100);
        if (r < 80) return Material.STONE_BRICKS;
        if (r < 90) return Material.CRACKED_STONE_BRICKS;
        return Material.MOSSY_STONE_BRICKS;
    }

    private void buildArena(int dir) {
        // walls
        for (int lz = 0; lz <= LEN; lz++) {
            for (int lx = -HALF; lx <= HALF; lx++) {
                boolean boundary = (lz == 0 || lz == LEN || Math.abs(lx) == HALF);
                if (!boundary) continue;
                int x = wx(dir, lx, lz), z = wz(dir, lx, lz);
                boolean gate = (lz == 0 && lx == 0);
                for (int y = 1; y <= 5; y++) {
                    if (gate && y <= 2) continue;
                    set(x, y0 + y, z, wallMat());
                }
                if (!gate && ((lx + lz) & 1) == 0) set(x, y0 + 6, z, Material.STONE_BRICKS);
            }
        }
        // gate (closed fence gate, mobs can't open it, players can)
        {
            int x = wx(dir, 0, 0), z = wz(dir, 0, 0);
            Directional g = (Directional) Material.DARK_OAK_FENCE_GATE.createBlockData();
            g.setFacing(face(OUT[dir][0], OUT[dir][1]));
            set(x, y0 + 1, z, g);
            set(x, y0 + 2, z, Material.AIR);
        }

        // floor
        for (int lz = 1; lz <= LEN - 1; lz++) {
            for (int lx = -HALF + 1; lx <= HALF - 1; lx++) {
                int x = wx(dir, lx, lz), z = wz(dir, lx, lz);
                double d = Math.sqrt(lx * lx + (lz - 11) * (lz - 11));
                Material m;
                if (d <= 4) m = Material.RED_NETHER_BRICKS;
                else if (d <= 5) m = Material.POLISHED_BLACKSTONE;
                else m = (((lx + lz) & 1) == 0) ? Material.DEEPSLATE_TILES : Material.POLISHED_DEEPSLATE;
                set(x, y0, z, m);
            }
        }

        // corner pillars with light
        for (int sgn = -1; sgn <= 1; sgn += 2) {
            for (int lz : new int[]{2, LEN - 2}) {
                int x = wx(dir, 9 * sgn, lz), z = wz(dir, 9 * sgn, lz);
                for (int y = 1; y <= 4; y++) set(x, y0 + y, z, Material.STONE_BRICKS);
                set(x, y0 + 5, z, Material.SHROOMLIGHT);
            }
        }

        Zone z = addZone("arena", ZoneType.COMBAT, dir, -HALF + 1, 1, HALF - 1, LEN - 1, y0, y0 + 6);
        z.mobType = EntityType.ZOMBIE;
        z.maxMobs = 8;
        z.respawnSeconds = 4;
    }

    // ---------------------------------------------------------- decoration

    private void buildDecoration() {
        List<Material> deco = new ArrayList<>();
        Material grass = Material.matchMaterial("SHORT_GRASS");
        if (grass == null) grass = Material.matchMaterial("GRASS");
        if (grass != null) {
            deco.add(grass);
            deco.add(grass);
            deco.add(grass);
        }
        deco.add(Material.DANDELION);
        deco.add(Material.POPPY);
        deco.add(Material.AZURE_BLUET);
        deco.add(Material.CORNFLOWER);
        deco.add(Material.OXEYE_DAISY);

        for (int dx = -(R - 3); dx <= R - 3; dx++) {
            for (int dz = -(R - 3); dz <= R - 3; dz++) {
                if (dx * dx + dz * dz > (R - 3) * (R - 3)) continue;
                int x = cx + dx, z = cz + dz;
                if (reserved.contains(col(x, z))) continue;
                if (typeAt(x, y0, z) != Material.GRASS_BLOCK) continue;
                if (ops.containsKey(key(x, y0 + 1, z))) continue;
                if (rnd.nextInt(10) != 0) continue;
                set(x, y0 + 1, z, deco.get(rnd.nextInt(deco.size())));
            }
        }
    }

    /** Fences don't auto-connect when placed without physics, so connect them ourselves. */
    private void finishFences() {
        BlockFace[] faces = {BlockFace.NORTH, BlockFace.EAST, BlockFace.SOUTH, BlockFace.WEST};
        for (Op o : ops.values()) {
            if (o.d instanceof Fence f0) {
                Fence f = (Fence) f0.clone();
                for (BlockFace bf : faces) {
                    Material n = typeAt(o.x + bf.getModX(), o.y, o.z + bf.getModZ());
                    f.setFace(bf, n != null && n.name().endsWith("_FENCE"));
                }
                o.d = f;
            }
        }
    }
}
