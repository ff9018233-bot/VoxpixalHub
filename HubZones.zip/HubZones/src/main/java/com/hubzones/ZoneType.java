package com.hubzones;

public enum ZoneType {
    MINING, FARMING, TREE, COMBAT
}
