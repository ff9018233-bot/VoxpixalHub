package com.hubzones;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Leaves;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityCombustByBlockEvent;
import org.bukkit.event.entity.EntityCombustByEntityEvent;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class HubZones extends JavaPlugin implements Listener, TabExecutor {

    private static class Pending {
        final BlockData data;
        final Location loc;
        BukkitTask task;

        Pending(BlockData data, Location loc) {
            this.data = data;
            this.loc = loc;
        }
    }

    private final Map<String, Zone> zones = new LinkedHashMap<>();
    private final Map<UUID, Location[]> selections = new HashMap<>();
    private final Map<String, Pending> pending = new HashMap<>();
    private final Map<ZoneType, Set<Material>> allowed = new EnumMap<>(ZoneType.class);
    private final Random rnd = new Random();
    private final Map<UUID, Long> genConfirm = new HashMap<>();

    private NamespacedKey wandKey;
    private NamespacedKey mobKey;
    private File zoneFile;

    private String hubWorld;
    private double hx, hy, hz;
    private float hyaw, hpitch;

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        wandKey = new NamespacedKey(this, "wand");
        mobKey = new NamespacedKey(this, "zone");
        zoneFile = new File(getDataFolder(), "zones.yml");
        loadAll();

        getServer().getPluginManager().registerEvents(this, this);
        getCommand("hubzones").setExecutor(this);
        getCommand("hubzones").setTabCompleter(this);
        getCommand("hub").setExecutor(this);

        Bukkit.getScheduler().runTaskTimer(this, this::combatTick, 20L, 10L);
    }

    @Override
    public void onDisable() {
        restoreAll();
    }

    private void loadAll() {
        reloadConfig();
        buildAllowed();
        zones.clear();
        hubWorld = null;

        YamlConfiguration y = YamlConfiguration.loadConfiguration(zoneFile);
        ConfigurationSection hs = y.getConfigurationSection("hub");
        if (hs != null) {
            hubWorld = hs.getString("world");
            hx = hs.getDouble("x");
            hy = hs.getDouble("y");
            hz = hs.getDouble("z");
            hyaw = (float) hs.getDouble("yaw");
            hpitch = (float) hs.getDouble("pitch");
        }
        ConfigurationSection zs = y.getConfigurationSection("zones");
        if (zs != null) {
            for (String name : zs.getKeys(false)) {
                ConfigurationSection s = zs.getConfigurationSection(name);
                if (s == null) continue;
                try {
                    ZoneType t = ZoneType.valueOf(s.getString("type", "MINING"));
                    Zone z = new Zone(name, t, s.getString("world", "world"),
                            s.getInt("x1"), s.getInt("y1"), s.getInt("z1"),
                            s.getInt("x2"), s.getInt("y2"), s.getInt("z2"));
                    z.mobType = EntityType.valueOf(s.getString("mob", "ZOMBIE"));
                    z.maxMobs = s.getInt("max-mobs", 6);
                    z.respawnSeconds = s.getInt("respawn-seconds", 5);
                    zones.put(name.toLowerCase(), z);
                } catch (IllegalArgumentException ex) {
                    getLogger().warning("Could not load zone " + name + ": " + ex.getMessage());
                }
            }
        }
        getLogger().info("Loaded " + zones.size() + " zone(s).");
    }

    private void saveAll() {
        YamlConfiguration y = new YamlConfiguration();
        if (hubWorld != null) {
            y.set("hub.world", hubWorld);
            y.set("hub.x", hx);
            y.set("hub.y", hy);
            y.set("hub.z", hz);
            y.set("hub.yaw", (double) hyaw);
            y.set("hub.pitch", (double) hpitch);
        }
        for (Zone z : zones.values()) {
            String p = "zones." + z.name + ".";
            y.set(p + "type", z.type.name());
            y.set(p + "world", z.world);
            y.set(p + "x1", z.minX);
            y.set(p + "y1", z.minY);
            y.set(p + "z1", z.minZ);
            y.set(p + "x2", z.maxX);
            y.set(p + "y2", z.maxY);
            y.set(p + "z2", z.maxZ);
            y.set(p + "mob", z.mobType.name());
            y.set(p + "max-mobs", z.maxMobs);
            y.set(p + "respawn-seconds", z.respawnSeconds);
        }
        try {
            getDataFolder().mkdirs();
            y.save(zoneFile);
        } catch (IOException e) {
            getLogger().warning("Could not save zones.yml: " + e.getMessage());
        }
    }

    private void buildAllowed() {
        allowed.clear();
        for (ZoneType t : ZoneType.values()) {
            Set<Material> set = EnumSet.noneOf(Material.class);
            for (String raw : getConfig().getStringList("zones." + t.name() + ".blocks")) {
                String pat = raw.toUpperCase();
                if (pat.startsWith("*")) {
                    String suffix = pat.substring(1);
                    for (Material m : Material.values()) {
                        if (!m.isLegacy() && m.name().endsWith(suffix)) set.add(m);
                    }
                } else {
                    Material m = Material.matchMaterial(pat);
                    if (m != null) set.add(m);
                    else getLogger().warning("Unknown material in config: " + raw);
                }
            }
            allowed.put(t, set);
        }
    }

    // ------------------------------------------------------------------ helpers

    /** Called by HubGenerator once the hub island is built. */
    public void registerGeneratedHub(Location spawn, List<Zone> newZones) {
        for (Zone z : newZones) zones.put(z.name.toLowerCase(), z);
        hubWorld = spawn.getWorld().getName();
        hx = spawn.getX();
        hy = spawn.getY();
        hz = spawn.getZ();
        hyaw = spawn.getYaw();
        hpitch = spawn.getPitch();
        saveAll();
    }

    private Location hub() {
        if (hubWorld == null) return null;
        World w = Bukkit.getWorld(hubWorld);
        if (w == null) return null;
        return new Location(w, hx, hy, hz, hyaw, hpitch);
    }

    private Zone zoneAt(Block b) {
        for (Zone z : zones.values()) {
            if (z.contains(b)) return z;
        }
        return null;
    }

    private boolean isHubWorld(World w) {
        return getConfig().getBoolean("protect-hub-world", true)
                && hubWorld != null && w.getName().equals(hubWorld);
    }

    private boolean canBuild(Player p) {
        return p.hasPermission("hubzones.build") && p.getGameMode() == GameMode.CREATIVE;
    }

    private boolean isWand(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(wandKey, PersistentDataType.BYTE);
    }

    private String key(Block b) {
        return b.getWorld().getName() + ":" + b.getX() + "," + b.getY() + "," + b.getZ();
    }

    private void msg(CommandSender s, String m) {
        s.sendMessage(ChatColor.translateAlternateColorCodes('&', "&6[HubZones] &f" + m));
    }

    private int delayFor(ZoneType t) {
        if (t == ZoneType.TREE) {
            int min = getConfig().getInt("zones.TREE.respawn-ticks-min", 60);
            int max = Math.max(min, getConfig().getInt("zones.TREE.respawn-ticks-max", 80));
            return min + rnd.nextInt(max - min + 1);
        }
        return getConfig().getInt("zones." + t.name() + ".respawn-ticks", 100);
    }

    // ------------------------------------------------------------------ block regen

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Block b = e.getBlock();

        if (isWand(p.getInventory().getItemInMainHand())) {
            e.setCancelled(true);
            return;
        }
        if (canBuild(p)) return;

        Zone z = zoneAt(b);
        if (z == null) {
            if (isHubWorld(b.getWorld())) e.setCancelled(true);
            return;
        }
        if (z.type == ZoneType.COMBAT || !allowed.get(z.type).contains(b.getType())) {
            e.setCancelled(true);
            return;
        }

        final String k = key(b);
        if (pending.containsKey(k)) {
            e.setCancelled(true);
            return;
        }

        BlockData original = b.getBlockData().clone();

        if (getConfig().getBoolean("auto-pickup", true)) {
            e.setDropItems(false);
            for (ItemStack drop : b.getDrops(p.getInventory().getItemInMainHand(), p)) {
                Map<Integer, ItemStack> left = p.getInventory().addItem(drop);
                for (ItemStack rest : left.values()) {
                    b.getWorld().dropItemNaturally(b.getLocation(), rest);
                }
            }
        }

        String phName = getConfig().getString("zones." + z.type.name() + ".placeholder", "");
        final Material placeholder = (phName == null || phName.isEmpty()) ? null : Material.matchMaterial(phName);

        Pending pd = new Pending(original, b.getLocation());
        pending.put(k, pd);

        if (placeholder != null) {
            Bukkit.getScheduler().runTask(this, () -> {
                if (b.getType().isAir()) b.setType(placeholder, false);
            });
        }
        pd.task = Bukkit.getScheduler().runTaskLater(this, () -> restore(k), delayFor(z.type));
    }

    private void restore(String k) {
        Pending pd = pending.get(k);
        if (pd == null) return;

        Block b = pd.loc.getBlock();
        BlockData d = pd.data.clone();

        // don't entomb a player inside a solid block; try again in 1 second
        if (d.getMaterial().isSolid()) {
            BoundingBox bb = BoundingBox.of(b);
            for (Player pl : b.getWorld().getPlayers()) {
                if (pl.getBoundingBox().overlaps(bb)) {
                    pd.task = Bukkit.getScheduler().runTaskLater(this, () -> restore(k), 20L);
                    return;
                }
            }
        }

        if (d instanceof Ageable a) a.setAge(a.getMaximumAge());
        if (d instanceof Leaves lv) lv.setPersistent(true);

        b.setBlockData(d, false);
        pending.remove(k);
    }

    private void restoreAll() {
        for (Pending pd : new ArrayList<>(pending.values())) {
            if (pd.task != null) pd.task.cancel();
            BlockData d = pd.data.clone();
            if (d instanceof Ageable a) a.setAge(a.getMaximumAge());
            if (d instanceof Leaves lv) lv.setPersistent(true);
            pd.loc.getBlock().setBlockData(d, false);
        }
        pending.clear();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (canBuild(p)) return;
        Block b = e.getBlock();
        if (zoneAt(b) != null || isHubWorld(b.getWorld())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent e) {
        if (canBuild(e.getPlayer())) return;
        Block b = e.getBlock();
        if (zoneAt(b) != null || isHubWorld(b.getWorld())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onLeavesDecay(LeavesDecayEvent e) {
        Block b = e.getBlock();
        if (zoneAt(b) != null || isHubWorld(b.getWorld())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityChangeBlock(EntityChangeBlockEvent e) {
        Block b = e.getBlock();
        if (b.getType() == Material.FARMLAND && (zoneAt(b) != null || isHubWorld(b.getWorld()))) {
            e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------ wand + farmland

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() == Action.PHYSICAL) {
            Block b = e.getClickedBlock();
            if (b != null && b.getType() == Material.FARMLAND
                    && (zoneAt(b) != null || isHubWorld(b.getWorld()))) {
                e.setCancelled(true);
            }
            return;
        }
        if (e.getHand() != EquipmentSlot.HAND || e.getClickedBlock() == null) return;
        if (!isWand(e.getItem())) return;

        Player p = e.getPlayer();
        if (!p.hasPermission("hubzones.admin")) return;
        e.setCancelled(true);

        Location[] sel = selections.computeIfAbsent(p.getUniqueId(), k -> new Location[2]);
        Location loc = e.getClickedBlock().getLocation();
        if (e.getAction() == Action.LEFT_CLICK_BLOCK) {
            sel[0] = loc;
            msg(p, "Position 1 set: " + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ());
        } else if (e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            sel[1] = loc;
            msg(p, "Position 2 set: " + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ());
        }
    }

    // ------------------------------------------------------------------ hub

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!getConfig().getBoolean("teleport-on-join", true)) return;
        Location h = hub();
        if (h != null) e.getPlayer().teleport(h);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        if (!getConfig().getBoolean("respawn-at-hub", true)) return;
        Location h = hub();
        if (h != null && !e.isBedSpawn()) e.setRespawnLocation(h);
    }

    @EventHandler(ignoreCancelled = true)
    public void onNaturalSpawn(CreatureSpawnEvent e) {
        if (e.getSpawnReason() == CreatureSpawnEvent.SpawnReason.NATURAL
                && getConfig().getBoolean("block-natural-mob-spawn", true)
                && isHubWorld(e.getLocation().getWorld())) {
            e.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------ combat zones

    private boolean isZoneMob(Entity ent) {
        return ent.getPersistentDataContainer().has(mobKey, PersistentDataType.STRING);
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent e) {
        String zn = e.getEntity().getPersistentDataContainer().get(mobKey, PersistentDataType.STRING);
        if (zn == null) return;
        Zone z = zones.get(zn.toLowerCase());
        if (z == null) return;
        z.respawnQueue.add(System.currentTimeMillis() + z.respawnSeconds * 1000L);
    }

    @EventHandler(ignoreCancelled = true)
    public void onCombust(EntityCombustEvent e) {
        // stop zone mobs from burning in daylight (but still allow fire aspect / lava etc.)
        if (e instanceof EntityCombustByEntityEvent || e instanceof EntityCombustByBlockEvent) return;
        if (isZoneMob(e.getEntity())) e.setCancelled(true);
    }

    private Location randomSpot(Zone z, World w) {
        for (int i = 0; i < 30; i++) {
            int x = z.minX + rnd.nextInt(z.maxX - z.minX + 1);
            int zz = z.minZ + rnd.nextInt(z.maxZ - z.minZ + 1);
            for (int y = z.maxY - 1; y >= z.minY; y--) {
                Block floor = w.getBlockAt(x, y, zz);
                Block a1 = w.getBlockAt(x, y + 1, zz);
                Block a2 = w.getBlockAt(x, y + 2, zz);
                if (floor.getType().isSolid() && !floor.isLiquid()
                        && a1.isPassable() && !a1.isLiquid()
                        && a2.isPassable() && !a2.isLiquid()) {
                    return new Location(w, x + 0.5, y + 1, zz + 0.5);
                }
            }
        }
        return null;
    }

    private void combatTick() {
        long now = System.currentTimeMillis();
        for (Zone z : zones.values()) {
            if (z.type != ZoneType.COMBAT) continue;
            World w = Bukkit.getWorld(z.world);
            if (w == null) continue;

            BoundingBox box = z.box();
            BoundingBox near = box.clone().expand(48);
            boolean playerNear = false;
            for (Player p : w.getPlayers()) {
                if (near.contains(p.getLocation().toVector())) {
                    playerNear = true;
                    break;
                }
            }
            if (!playerNear) continue;

            int count = 0;
            for (Entity ent : w.getNearbyEntities(box.clone().expand(16))) {
                if (!(ent instanceof LivingEntity) || ent.isDead()) continue;
                String zn = ent.getPersistentDataContainer().get(mobKey, PersistentDataType.STRING);
                if (zn == null || !zn.equalsIgnoreCase(z.name)) continue;
                count++;
                if (!box.contains(ent.getLocation().toVector())) {
                    Location back = randomSpot(z, w);
                    if (back != null) {
                        ent.teleport(back);
                        ent.setFallDistance(0);
                    }
                }
            }

            int missing = z.maxMobs - count;
            while (z.respawnQueue.size() > Math.max(0, missing)) {
                z.respawnQueue.remove(z.respawnQueue.size() - 1);
            }
            if (missing <= 0) continue;

            boolean spawn = false;
            if (z.respawnQueue.isEmpty()) {
                spawn = true;
            } else if (z.respawnQueue.get(0) <= now) {
                z.respawnQueue.remove(0);
                spawn = true;
            }
            if (!spawn) continue;

            Location s = randomSpot(z, w);
            if (s == null) continue;
            Entity en = w.spawnEntity(s, z.mobType);
            if (en instanceof LivingEntity le) {
                le.getPersistentDataContainer().set(mobKey, PersistentDataType.STRING, z.name);
                le.setPersistent(true);
                le.setRemoveWhenFarAway(false);
            } else {
                en.remove();
            }
        }
    }

    // ------------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (c.getName().equalsIgnoreCase("hub")) {
            if (!(s instanceof Player p)) {
                msg(s, "Only players can use this.");
                return true;
            }
            Location h = hub();
            if (h == null) msg(p, "Hub is not set yet. An admin must use /hz sethub.");
            else p.teleport(h);
            return true;
        }

        if (!s.hasPermission("hubzones.admin")) {
            msg(s, "&cYou don't have permission.");
            return true;
        }
        if (a.length == 0 || a[0].equalsIgnoreCase("help")) {
            msg(s, "/hz wand - selection tool (left click = pos1, right click = pos2)");
            msg(s, "/hz pos1 | /hz pos2 - set position at your feet");
            msg(s, "/hz create <mining|farming|tree|combat> <name>");
            msg(s, "/hz set <name> mob <TYPE> | max <n> | respawn <seconds>  (combat zones)");
            msg(s, "/hz list | /hz delete <name> | /hz tp <name>");
            msg(s, "/hz generate - auto-build a Hypixel-style hub island with all 4 zones");
            msg(s, "/hz sethub | /hz reload | /hub");
            return true;
        }

        switch (a[0].toLowerCase()) {
            case "wand": {
                if (!(s instanceof Player p)) return true;
                ItemStack it = new ItemStack(Material.GOLDEN_AXE);
                ItemMeta m = it.getItemMeta();
                m.setDisplayName(ChatColor.GOLD + "HubZones Wand");
                m.getPersistentDataContainer().set(wandKey, PersistentDataType.BYTE, (byte) 1);
                it.setItemMeta(m);
                p.getInventory().addItem(it);
                msg(p, "Left click = pos1, right click = pos2.");
                return true;
            }
            case "pos1":
            case "pos2": {
                if (!(s instanceof Player p)) return true;
                Location[] sel = selections.computeIfAbsent(p.getUniqueId(), k -> new Location[2]);
                int idx = a[0].equalsIgnoreCase("pos1") ? 0 : 1;
                sel[idx] = p.getLocation().getBlock().getLocation();
                msg(p, "Position " + (idx + 1) + " set.");
                return true;
            }
            case "create": {
                if (!(s instanceof Player p)) return true;
                if (a.length < 3) {
                    msg(p, "Usage: /hz create <mining|farming|tree|combat> <name>");
                    return true;
                }
                ZoneType t;
                try {
                    t = ZoneType.valueOf(a[1].toUpperCase());
                } catch (IllegalArgumentException ex) {
                    msg(p, "Type must be: mining, farming, tree or combat.");
                    return true;
                }
                String name = a[2];
                if (!name.matches("[A-Za-z0-9_-]+")) {
                    msg(p, "Name can only contain letters, numbers, _ and -.");
                    return true;
                }
                if (zones.containsKey(name.toLowerCase())) {
                    msg(p, "A zone with that name already exists.");
                    return true;
                }
                Location[] sel = selections.get(p.getUniqueId());
                if (sel == null || sel[0] == null || sel[1] == null) {
                    msg(p, "Select two corners first (/hz wand).");
                    return true;
                }
                if (!sel[0].getWorld().equals(sel[1].getWorld())) {
                    msg(p, "Both positions must be in the same world.");
                    return true;
                }
                Zone z = new Zone(name, t, sel[0].getWorld().getName(),
                        sel[0].getBlockX(), sel[0].getBlockY(), sel[0].getBlockZ(),
                        sel[1].getBlockX(), sel[1].getBlockY(), sel[1].getBlockZ());
                zones.put(name.toLowerCase(), z);
                saveAll();
                msg(p, "Created " + t + " zone '" + name + "'.");
                if (t == ZoneType.COMBAT) {
                    msg(p, "Tip: include 3-4 blocks of air above the floor so mobs can spawn. Use /hz set " + name + " mob SKELETON etc.");
                }
                return true;
            }
            case "delete": {
                if (a.length < 2) {
                    msg(s, "Usage: /hz delete <name>");
                    return true;
                }
                if (zones.remove(a[1].toLowerCase()) != null) {
                    saveAll();
                    msg(s, "Deleted.");
                } else {
                    msg(s, "No such zone.");
                }
                return true;
            }
            case "list": {
                if (zones.isEmpty()) msg(s, "No zones yet.");
                for (Zone z : zones.values()) {
                    msg(s, z.name + " &7(" + z.type + ", " + z.world + ")");
                }
                return true;
            }
            case "tp": {
                if (!(s instanceof Player p) || a.length < 2) return true;
                Zone z = zones.get(a[1].toLowerCase());
                World w = z == null ? null : Bukkit.getWorld(z.world);
                if (z == null || w == null) {
                    msg(p, "No such zone.");
                    return true;
                }
                Location t = randomSpot(z, w);
                if (t == null) {
                    t = new Location(w, (z.minX + z.maxX + 1) / 2.0, z.maxY + 1, (z.minZ + z.maxZ + 1) / 2.0);
                }
                p.teleport(t);
                return true;
            }
            case "set": {
                if (a.length < 4) {
                    msg(s, "Usage: /hz set <name> mob <TYPE> | max <n> | respawn <seconds>");
                    return true;
                }
                Zone z = zones.get(a[1].toLowerCase());
                if (z == null) {
                    msg(s, "No such zone.");
                    return true;
                }
                try {
                    switch (a[2].toLowerCase()) {
                        case "mob": {
                            EntityType et = EntityType.valueOf(a[3].toUpperCase());
                            if (!et.isAlive() || !et.isSpawnable()) {
                                msg(s, "That entity can't be used.");
                                return true;
                            }
                            z.mobType = et;
                            break;
                        }
                        case "max":
                            z.maxMobs = Math.max(1, Integer.parseInt(a[3]));
                            break;
                        case "respawn":
                            z.respawnSeconds = Math.max(1, Integer.parseInt(a[3]));
                            break;
                        default:
                            msg(s, "Use mob, max or respawn.");
                            return true;
                    }
                } catch (IllegalArgumentException ex) {
                    msg(s, "Invalid value.");
                    return true;
                }
                saveAll();
                msg(s, "Updated " + z.name + ": " + z.mobType + " x" + z.maxMobs + ", respawn " + z.respawnSeconds + "s");
                return true;
            }
            case "sethub": {
                if (!(s instanceof Player p)) return true;
                Location l = p.getLocation();
                hubWorld = l.getWorld().getName();
                hx = l.getX();
                hy = l.getY();
                hz = l.getZ();
                hyaw = l.getYaw();
                hpitch = l.getPitch();
                saveAll();
                msg(p, "Hub set. Players can use /hub.");
                return true;
            }
            case "generate": {
                if (!(s instanceof Player p)) return true;
                long now = System.currentTimeMillis();
                boolean confirm = a.length > 1 && a[1].equalsIgnoreCase("confirm");
                if (!confirm) {
                    genConfirm.put(p.getUniqueId(), now + 30000L);
                    msg(p, "&eThis will BUILD a floating hub island (radius 56) centered on you,");
                    msg(p, "&eoverwriting blocks up to 19 below and 16 above you. Best done in an empty/void world.");
                    msg(p, "&eIt also creates zones: mine, farm, forest, arena (existing zones with those names are replaced).");
                    msg(p, "&aType &f/hz generate confirm &awithin 30 seconds to continue.");
                    return true;
                }
                Long until = genConfirm.remove(p.getUniqueId());
                if (until == null || until < now) {
                    msg(p, "Run /hz generate first.");
                    return true;
                }
                new HubGenerator(this, p).start();
                return true;
            }
            case "reload": {
                restoreAll();
                loadAll();
                msg(s, "Reloaded.");
                return true;
            }
            default:
                msg(s, "Unknown subcommand. Use /hz help");
                return true;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (!c.getName().equalsIgnoreCase("hubzones") || !s.hasPermission("hubzones.admin")) {
            return Collections.emptyList();
        }
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out.addAll(Arrays.asList("wand", "pos1", "pos2", "create", "delete", "list", "tp", "set", "sethub", "generate", "reload", "help"));
        } else if (a.length == 2 && a[0].equalsIgnoreCase("create")) {
            for (ZoneType t : ZoneType.values()) out.add(t.name().toLowerCase());
        } else if (a.length == 2 && Arrays.asList("delete", "tp", "set").contains(a[0].toLowerCase())) {
            for (Zone z : zones.values()) out.add(z.name);
        } else if (a.length == 3 && a[0].equalsIgnoreCase("set")) {
            out.addAll(Arrays.asList("mob", "max", "respawn"));
        } else if (a.length == 4 && a[0].equalsIgnoreCase("set") && a[2].equalsIgnoreCase("mob")) {
            out.addAll(Arrays.asList("ZOMBIE", "SKELETON", "SPIDER", "CREEPER", "HUSK", "STRAY", "ZOMBIE_VILLAGER"));
        }
        String last = a[a.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }
}
